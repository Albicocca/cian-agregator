var districts={
    'cao':['arbat','basmannyj','zamoskvoreche','krasnoselskij','meshchanskij','presnenskij','taganskij','tverskoj','hamovniki','yakimanka'],
    'sao':['aeroport','begovoj','beskudnikovskij','vojkovskij','golovinskij','degunino_vostochnoe','degunino_zapadnoe','dmitrovskij','koptevo','levoberezhnyj','molzhaninovskij','savelovskij','sokol','timiryazevskij','hovrino','horoshevskij'],
    'svao':['alekseevskij','altufevskij','babushkinskij','bibirevo','butyrskij','lianozovo','losinoostrovskij','marfino','marina_roshcha','medvedkovo_severnoe','medvedkovo_yuzhnoe','ostankinskij','otradnoe','rostokino','sviblovo','severnyj','yaroslavskij'],
    'vao':['bogorodskoe','veshnyaki','vostochnyj','golyanovo','ivanovskoe','izmajlovo_vostochnoe','izmajlovo','izmajlovo_severnoe','kosino-uhtomskij','metrogorodok','novogireevo','novokosino','perovo','preobrazhenskoe','sokolinaya_gora','sokolniki'],
    'uvao':['vyhino-zhulebino','kapotnya','kuzminki','lefortovo','lyublino','marino','nekrasovka','nizhegorodskij','pechatniki','ryazanskij','tekstilshchiki','yuzhnoportovyj'],
    'uao':['biryulevo_vostochnoe','biryulevo_zapadnoe','brateevo','danilovskij','donskoj','zyablikovo','moskvoreche-saburovo','nagatino-sadovniki','nagatinskij_zaton','nagornyj','orehovo-borisovo_severnoe','orehovo-borisovo_yuzhnoe','caricyno','chertanovo_severnoe','chertanovo_centralnoe','chertanovo_yuzhnoe'],
    'uzao':['akademicheskij','butovo_severnoe','butovo_yuzhnoe','gagarinskij','zyuzino','konkovo','kotlovka','lomonosovskij','obruchevskij','teplyj_stan','cheremushki','yasenevo'],
    'zao':['vnukovo','dorogomilovo','krylatskoe','kuncevo','mozhajskij','novo-peredelkino','ochakovo-matveevskoe','prospekt_vernadskogo','ramenki','solncevo','troparevo-nikulino','filevskij_park','fili-davydkovo'],
    'szao':['kurkino','mitino','pokrovskoe-streshnevo','strogino','tushino_severnoe','tushino_yuzhnoe','horoshevo-mnevniki','shchukino'],
    'zelao':['kryukovo','matushkino','savelki','silino','staroe_kryukovo']}
